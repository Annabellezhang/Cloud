package assign1;

public class record {
	double x;
	double y;
	String content;
	String location;
	String username;
}
